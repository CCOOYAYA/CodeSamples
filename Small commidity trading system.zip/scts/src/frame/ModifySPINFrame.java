package frame;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Vector;

import model.SPModel;
import util.WindowUtil;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;

import bean.Shangpin;
import dao.ManageHelper;

//�޸��û���Ϣ����
public class ModifySPINFrame extends JDialog{
 	private JButton modify_Button;	//"�޸�"��ť��
    private JButton cancel_Button;	//"ȡ��"��ť�� 
    private JLabel name;    //"�̼���"��ǩ��
    private JLabel spname;	//"��Ʒ��"��ǩ��
    private JLabel classes;	//"���"��ǩ��l
    private JLabel price;	//"�۸�"��ǩ��
    private JLabel number;	//"������ǩ"��
    private JLabel freshdate;	//"������"��ǩ��
    private JTextField nametext;	
    private JTextField spnametext;	
    private JTextField classestext;	
    private JTextField pricetext;	
    private JTextField numbertext;
    private JTextField freshdatetext;
    private JDialog jd;	//��ǰ���ڡ�
    private ManageHelper helper;	//���ݿ�ҵ��������
    private SPModel spmodel;	//�û�����ģ�Ͷ���
	/**
	 * 
	 * @param owner ���ĸ�����
	 * @param title ������
	 * @param modal ָ����ģʽ���ڣ����з�ģʽ����
	 */
	public ModifySPINFrame(JDialog owner, String title, boolean modal,int rowNum,SPModel spmodel){
		super(owner, title, modal);
		helper = new ManageHelper();	//�������ݿ�ҵ��������
		this.jd = this;
		this.spmodel = spmodel;
		this.setSize(350,429);	//���ô����С��
		this.setLayout(null);	//���ÿղ��֡�
		//��ȡ��Ϣ
		String name1 = spmodel.getValueAt(rowNum, 0).toString();
		String spname1 = spmodel.getValueAt(rowNum, 1).toString();
		String classes1 = spmodel.getValueAt(rowNum, 2).toString();
		String price1 = spmodel.getValueAt(rowNum, 3).toString();
		String number1 = spmodel.getValueAt(rowNum, 4).toString();
		String freshdate1 = spmodel.getValueAt(rowNum, 5).toString();
		
			
    	name = new JLabel("�̼�:");
    	name.setBounds(29, 19, 30, 20);
    	this.add(name);
    	nametext = new JTextField();
    	nametext.setBounds(65, 19, 100, 20);
    	nametext.setText(name1);
    	nametext.setEditable(false);
    	this.add(nametext);
    	
    	
    	spname = new JLabel("��Ʒ��:");
    	spname.setBounds(200, 19, 30, 20);
    	this.add(spname);
    	spnametext = new JTextField();
    	spnametext.setBounds(240, 19, 100, 20);
    	spnametext.setText(spname1);
    	spnametext.setEditable(false);
    	this.add(spnametext);
    	
    	classes = new JLabel("���:");
    	classes.setBounds(29, 50, 30, 20);
    	this.add(classes);
    	classestext = new JTextField();
    	classestext.setBounds(65, 50, 100, 20);
    	classestext.setText(classes1);
    	this.add(classestext);
    	
    	price = new JLabel("�۸�:");
    	price.setBounds(200, 50, 30, 20);
    	this.add(price);
    	pricetext = new JTextField();
    	pricetext.setBounds(240, 50, 100, 20);
    	pricetext.setText(price1);
    	this.add(pricetext);
    	
    	number = new JLabel("����:");
    	number.setBounds(29, 83, 30, 20);
    	this.add(number);
    	numbertext = new JTextField();
    	numbertext.setBounds(65, 83, 100, 20);
    	numbertext.setText(number1);
    	this.add(numbertext);
    	
    	freshdate = new JLabel("������:");
    	freshdate.setBounds(200, 83, 30, 20);
    	this.add(freshdate);
    	freshdatetext = new JTextField();
    	freshdatetext.setBounds(240, 83, 100, 20);
    	freshdatetext.setText(freshdate1);
    	this.add(freshdatetext);
    	
    	
		modify_Button = new JButton("�޸�");
		modify_Button.setBounds(70, 345, 60, 25);
		
		
		//ע��"�޸�"��ť�¼�����
		modify_Button.addActionListener(new ActionListener() {
			
			@Override 
			public void actionPerformed(ActionEvent e) {
				Shangpin sp = new Shangpin();
				String name = nametext.getText().trim();
				String spname = spnametext.getText().trim();
				String classes = classestext.getText().trim();
				String price = pricetext.getText().trim();
				String number = numbertext.getText().trim();
				String freshdate = freshdatetext.getText().trim();
				//����У�鲿��
				
				if(name.equals("")){
					JOptionPane.showMessageDialog(jd, "�̼�������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(spname.equals("")){
					JOptionPane.showMessageDialog(jd, "��Ʒ������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(classes.equals("")){
					JOptionPane.showMessageDialog(jd, "�����Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(price.equals("")){
					JOptionPane.showMessageDialog(jd, "�۸���Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(number.equals("")){
					JOptionPane.showMessageDialog(jd, "��������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(freshdate.equals("")){
					JOptionPane.showMessageDialog(jd, "�����ڲ���Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				sp.setName(name);
				sp.setSPName(spname);
				sp.setClasses(classes);
				sp.setPrice(price);
				sp.setNumber(number);
				sp.setFreshDate(freshdate);
				
			
				if(helper.updateSP(sp)){
					JOptionPane.showMessageDialog(jd, "�޸ĳɹ���");
					jd.dispose();	//�رյ�ǰ����
					return ;
				}else{
					JOptionPane.showMessageDialog(jd, "�޸�ʧ�ܣ�", "", JOptionPane.WARNING_MESSAGE);
					jd.dispose();	//�رյ�ǰ����
					return ;
				}
			}
			
		});
		this.add(modify_Button);
		
		cancel_Button = new JButton("ȡ��");
		cancel_Button.setBounds(230, 330, 60, 25);
		//ע��"ȡ��"��ť�¼�����
		cancel_Button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jd.dispose();
				
			}
		});
		this.add(cancel_Button);
			
		WindowUtil.setFrameCenter(this);
		this.setResizable(false);
		this.setVisible(true);

	}
}

	
	
	
	
	
	