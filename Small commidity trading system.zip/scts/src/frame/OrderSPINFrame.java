package frame;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Vector;

import model.SPModel;
import util.WindowUtil;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;

import bean.Shangpin;
import bean.User;
import bean.SPDG;
import dao.ManageHelper;

//��Ʒ��������
public class OrderSPINFrame extends JDialog{
 	private JButton order_Button;	//"����"��ť��
    private JButton cancel_Button;	//"ȡ��"��ť�� 
    private JLabel username;    //"�û���"��ǩ��
    private JLabel name;	//"����"��ǩ��
    private JLabel spname;   //"��Ʒ��"��ǩ
    private JLabel number;	//"������ǩ"��
    private JLabel orderdate;  //��������
    private JLabel text;   //��ע
    private JTextField usernametext;
    private JTextField nametext;	
    private JTextField spnametext;	
    private JTextField numbertext;
    private JTextField orderdatetext;
    private JTextField texttext;
    private JDialog jd;	//��ǰ���ڡ�
    private ManageHelper helper;	//���ݿ�ҵ��������
    private SPModel spmodel;	//�û�����ģ�Ͷ���
    private User user;
	/**
	 * 
	 * @param owner ���ĸ�����
	 * @param title ������
	 * @param modal ָ����ģʽ���ڣ����з�ģʽ����
	 */
	public OrderSPINFrame(JDialog owner, String title, boolean modal,int rowNum,SPModel spmodel,User user){
		super(owner, title, modal);
		helper = new ManageHelper();	//�������ݿ�ҵ��������
		this.jd = this;
		this.user = user;
		this.spmodel = spmodel;
		this.setSize(350,429);	//���ô����С��
		this.setLayout(null);	//���ÿղ��֡�
		//��ȡ��Ϣ
		String name1 = spmodel.getValueAt(rowNum, 0).toString();
		String spname1 = spmodel.getValueAt(rowNum, 1).toString();
		String classes1 = spmodel.getValueAt(rowNum, 2).toString();
		String price1 = spmodel.getValueAt(rowNum, 3).toString();
		String number1 = spmodel.getValueAt(rowNum, 4).toString();
		String freshdate1 = spmodel.getValueAt(rowNum, 5).toString();
		
			
    	username = new JLabel("�û���:");
    	username.setBounds(29, 19, 30, 20);
    	this.add(username);
    	usernametext = new JTextField();
    	usernametext.setBounds(65, 19, 100, 20);
    	usernametext.setText(user.getUsername());
    	usernametext.setEditable(false);
    	this.add(usernametext);
    	
    	
    	name = new JLabel("����:");
    	name.setBounds(200, 19, 30, 20);
    	this.add(name);
    	nametext = new JTextField();
    	nametext.setBounds(240, 19, 100, 20);
    	nametext.setText(user.getname());
    	nametext.setEditable(false);
    	this.add(nametext);
    	
    	spname = new JLabel("��Ʒ��:");
    	spname.setBounds(29, 50, 30, 20);
    	this.add(spname);
    	spnametext = new JTextField();
    	spnametext.setBounds(65, 50, 100, 20);
    	spnametext.setText(spname1);
    	spnametext.setEditable(false);
    	this.add(spnametext);
    	
    	number = new JLabel("��������:");
    	number.setBounds(200, 50, 30, 20);
    	this.add(number);
    	numbertext = new JTextField();
    	numbertext.setBounds(240, 50, 100, 20);
    	this.add(numbertext);
    	
    	number = new JLabel("����:");
    	number.setBounds(29, 83, 30, 20);
    	this.add(number);
    	numbertext = new JTextField();
    	numbertext.setBounds(65, 83, 100, 20);
    	this.add(numbertext);
    	
    	orderdate = new JLabel("��������:");
    	orderdate.setBounds(200, 83, 30, 20);
    	this.add(orderdate);
    	orderdatetext = new JTextField();
    	orderdatetext.setBounds(240, 83, 100, 20);
    	this.add(orderdatetext);
    	
    	text = new JLabel("��ע");
    	text.setBounds(29,113,30,20);
    	this.add(text);
    	texttext = new JTextField();
    	texttext.setBounds(65 , 113 , 100, 20);
    	this.add(texttext);
    	
    	
		order_Button = new JButton("ȷ�϶���");
		order_Button.setBounds(70, 345, 60, 25);
		
		
		//ע��"�޸�"��ť�¼�����
		order_Button.addActionListener(new ActionListener() {
			
			@Override 
			public void actionPerformed(ActionEvent e) {
				SPDG spdg = new SPDG();
				String username = usernametext.getText().trim();
				String name = nametext.getText().trim();
				String spname = spnametext.getText().trim();
				String number = numbertext.getText().trim();
				String orderdate = orderdatetext.getText().trim();
				String text = texttext.getText().trim();
				
			
				//����У�鲿��
				
				if(number.equals("")){
					JOptionPane.showMessageDialog(jd, "��������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(number.compareTo(number1)<0) {
					JOptionPane.showMessageDialog(jd, "���ﲻ�㣡", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(orderdate.equals("")){
					JOptionPane.showMessageDialog(jd, "�������ڲ���Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				
				spdg.setUser_Name(username);
				spdg.setName(name);
				spdg.setSPName(spname);
				spdg.setNumber(number);
				spdg.setOrderDate(orderdate);
				spdg.setText(text);
				
				if(helper.addspdg(spdg)){
					JOptionPane.showMessageDialog(jd, "�����ɹ���");
					jd.dispose();	//�رյ�ǰ����
					return ;
				}else{
					JOptionPane.showMessageDialog(jd, "����ʧ�ܣ�", "", JOptionPane.WARNING_MESSAGE);
					jd.dispose();	//�رյ�ǰ����
					return ;
				}
			}
			
		});
		this.add(order_Button);
		
		cancel_Button = new JButton("ȡ��");
		cancel_Button.setBounds(230, 330, 60, 25);
		//ע��"ȡ��"��ť�¼�����
		cancel_Button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jd.dispose();
				
			}
		});
		this.add(cancel_Button);
			
		WindowUtil.setFrameCenter(this);
		this.setResizable(false);
		this.setVisible(true);

	}
}

	
	
	
	
	
	