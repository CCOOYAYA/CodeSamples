package frame;

import util.WindowUtil;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import bean.Registed;
import dao.ManageHelper;
//����ѧ������
public class AddUserFrame extends JDialog{
	 	private JButton add_Button;	//"����"��ť��
	    private JButton cancel_Button;	//"ȡ��"��ť��
	    private JLabel User_Name;
	    private JTextField User_Nametext;
	    private JLabel Password;
	    private JTextField Passwordtext;
	    private JLabel Name;
	    private JLabel Identity;
	    private JComboBox ID_Box;
	    private JTextField Nametext;
	    private JComboBox Sex_Box;	//"�Ա�"ѡ�
	    private JLabel Sex;
	    private JLabel Contact;
	    private JTextField Contacttext;
	    private JLabel Address;
	    private JTextField Addresstext;
	    private JLabel Birthday;
	    private JTextField Birthdaytext;
	    private JLabel Else;
	    private JTextField Elsetext;
	    private JDialog jd;	//��ǰ���ڡ�
	    private ManageHelper helper;	//���ݿ�ҵ��������

	/**
	 * 
	 * @param owner ���ĸ�����
	 * @param title ������
	 * @param modal ָ����ģʽ���ڣ����з�ģʽ����
	 */
	public AddUserFrame(JFrame owner, String title, boolean modal){
		super(owner, title, modal);
		helper = new ManageHelper();	//�������ݿ�ҵ��������
		this.jd = this;
		this.setSize(350,429);	//���ô����С��
		this.setLayout(null);	//���ÿղ��֡�
		
		User_Name = new JLabel("�û���:");	
		User_Name.setBounds(78, 48, 50, 20);	
		this.add(User_Name);	
		
		User_Nametext = new JTextField();
		User_Nametext.setBounds(116, 48, 120, 20);
		this.add(User_Nametext);
		
		Password = new JLabel("����:");
		Password.setBounds(78, 78, 50, 20);
		this.add(Password);
		Passwordtext = new JTextField();
		Passwordtext.setBounds(116, 78, 120, 20);
		this.add(Passwordtext);
		
		Identity = new JLabel("����:");
		Identity.setBounds(78, 108, 50, 20);
		this.add(Identity);
		ID_Box = new JComboBox();
		ID_Box.setBounds(116, 108, 120, 20);
		ID_Box.addItem(" �� �� ");
		ID_Box.addItem(" �� ��");
		this.add(ID_Box);
		
		
		Name = new JLabel("����:");
		Name.setBounds(78, 138, 50, 20);
		this.add(Name);
		Nametext = new JTextField();
		Nametext.setBounds(116, 138, 120, 20);
		this.add(Nametext);
		
		Sex = new JLabel("�Ա�:");
		Sex.setBounds(78, 168, 50, 20);
		this.add(Sex);
		Sex_Box = new JComboBox();
		Sex_Box.setBounds(116, 168, 120, 20);
		Sex_Box.addItem(" �� ");
		Sex_Box.addItem(" Ů ");
		this.add(Sex_Box);
		
		
		
		Contact = new JLabel("��ϵ��ʽ:");	
		Contact.setBounds(78, 198, 50, 20);
		this.add(Contact);
		
		Contacttext = new JTextField();	
		Contacttext.setBounds(116, 198, 120, 20);
		this.add(Contacttext);
		
		
			
		Address = new JLabel("��ַ:");
		Address.setBounds(78, 228, 50, 20);
		this.add(Address);
		
		Addresstext = new JTextField();
		Addresstext.setBounds(116,228, 120, 20);
		this.add(Addresstext);

		Birthday = new JLabel("����:");
		Birthday.setBounds(78, 258, 50, 20);	
		this.add(Birthday);
		
		Birthdaytext = new JTextField();
		Birthdaytext.setBounds(116, 258, 120, 20);
		this.add(Birthdaytext);
		
		
		Else = new JLabel("��ע:");	
		Else.setBounds(78, 288, 50, 20);	
		this.add(Else);
		
		Elsetext = new JTextField();
		Elsetext.setBounds(116, 288, 120, 20);
		this.add(Elsetext);
		
		add_Button = new JButton("����");
		add_Button.setBounds(70, 330, 60, 25);
		
		//ע��"ȷ��"��ť�¼�����
		add_Button.addActionListener(new ActionListener() {
			
			@Override 
			public void actionPerformed(ActionEvent e) {
				Registed user = new Registed();
				String username = User_Nametext.getText().trim();
				String password = Passwordtext.getText().trim();
				int id = ID_Box.getSelectedIndex()+1;
				String name = Nametext.getText().trim();
				String sex = Sex_Box.getSelectedItem().toString();
				String contact = Contacttext.getText().trim();
				String address = Addresstext.getText().trim();
				String birthday = Birthdaytext.getText().trim();
				String els = Elsetext.getText().trim();
			
				if(username.equals("")){
					JOptionPane.showMessageDialog(jd, "�û�������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(password.equals("")){
					JOptionPane.showMessageDialog(jd, "�˺����벻��Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(name.equals("")){
					JOptionPane.showMessageDialog(jd, "��������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(contact.equals("")){
					JOptionPane.showMessageDialog(jd, "��ϵ��ʽ����Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				if(address.equals("")){
					JOptionPane.showMessageDialog(jd, "��ַ����Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
				
				user.setUser_Name(username);
				user.setPassword(password);
				user.setIdentity(id);
				user.setName(name);
				user.setSex(sex);
				user.setContact(contact);
				user.setAddress(address);
				user.setBirthday(birthday);
				user.setText(els);
				
				 

		
				if(helper.adduser(user)){
					JOptionPane.showMessageDialog(jd, "���ӳɹ���");
					jd.dispose();	//�رյ�ǰ����
					return ;
				}else{
					JOptionPane.showMessageDialog(jd, "����ʧ�ܣ�", "", JOptionPane.WARNING_MESSAGE);
					jd.dispose();	//�رյ�ǰ����
					return ;
				}
				
				
			}
		});
		this.add(add_Button);
		
		cancel_Button = new JButton("ȡ��");
		cancel_Button.setBounds(230, 330, 60, 25);
		//ע��"ȡ��"��ť�¼�����
		cancel_Button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jd.dispose();
				
			}
		});
		this.add(cancel_Button);
		
		WindowUtil.setFrameCenter(this);
		this.setResizable(false);
		this.setVisible(true);
	}
	
	
	
	
	
	
}
