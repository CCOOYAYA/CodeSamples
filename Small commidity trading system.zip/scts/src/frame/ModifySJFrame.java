
package frame;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Vector;

import model.UserModel;
import util.WindowUtil;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;

import bean.Registed;
import bean.User;
import dao.ManageHelper;

//�޸��û���Ϣ����
public class ModifySJFrame extends JDialog{
 	private JButton modify_Button;	//"�޸�"��ť��
    private JButton cancel_Button;	//"ȡ��"��ť�� 
    private JLabel username;    //"�û���"��ǩ��
    private JLabel name;	//"����"��ǩ��
    private JLabel sex;	//"�Ա�"��ǩ��l
    private JLabel contact;	//"��ϵ��ʽ"��ǩ��
    private JLabel address;	//"��ַ��ǩ"��
    private JLabel birthday;	//"����"��ǩ��
    private JLabel text;	//"��ע"��ǩ��
    private JTextArea usernametext;	
    private JTextField nametext;	
    private JComboBox sexbox;	//"�Ա�"ѡ�	
    private JTextField contacttext;	
    private JTextField addresstext;
    private JTextField birthdaytext;	
    private JTextField texttext;
    private JDialog jd;	//��ǰ���ڡ�
    private ManageHelper helper;	//���ݿ�ҵ��������
    private User user;
	/**
	 * 
	 * @param owner ���ĸ�����
	 * @param title ������
	 * @param modal ָ����ģʽ���ڣ����з�ģʽ����
	 */
    public ModifySJFrame(JFrame owner, String title, boolean modal,User user){
		super(owner, title, modal);
		helper = new ManageHelper();	//�������ݿ�ҵ��������
		this.user = user;
		this.jd = this;
		this.setSize(350,429);	//���ô����С��
		this.setLayout(null);	//���ÿղ���
			
		username = new JLabel("�û���:");
		username.setBounds(78, 88, 30, 20);
    	this.add(username);
    	usernametext = new JTextArea();
    	usernametext.setBounds(116, 88, 150, 20);
    	usernametext.setText(user.getUsername()); 
    	this.add(usernametext);
    	
    	
    	name = new JLabel("����:");
    	name.setBounds(78, 128, 30, 20);
    	this.add(name);
    	nametext = new JTextField();
    	nametext.setBounds(116, 128, 60, 20);
    	nametext.setText(user.getname());
    	this.add(nametext);
    	
    	sex = new JLabel("�Ա�:");
    	sex.setBounds(78, 168, 30, 20);
    	this.add(sex);
    	sexbox = new JComboBox(new String[]{"","��","Ů"});
		sexbox.setBounds(116, 168, 150, 20);
		this.add(sexbox);
    	
    	contact = new JLabel("��ϵ��ʽ:");
    	contact.setBounds(78, 208, 30, 20);
    	this.add(contact);
    	contacttext = new JTextField();
    	contacttext.setBounds(116, 208, 150, 20);
    	contacttext.setText(user.getContact());
    	this.add(contacttext);
    	
    	address = new JLabel("��ַ:");
    	address.setBounds(78, 248, 30, 20);	
    	this.add(address);
    	addresstext = new JTextField();
    	addresstext.setBounds(116, 248, 150, 20);
    	addresstext.setText(user.getAddress());
    	this.add(addresstext);
    	
    	birthday = new JLabel("����:");
    	birthday.setBounds(78, 288, 30, 20);
    	this.add(birthday);
    	birthdaytext = new JTextField();
    	birthdaytext.setBounds(116, 288, 150, 20);
    	birthdaytext.setText(user.getBirthday());
    	this.add(birthdaytext);
    	
    	text = new JLabel("��ע:");
    	text.setBounds(78,328, 30, 20);
    	this.add(text);
    	texttext = new JTextField();
    	texttext.setBounds(116, 328, 100, 20);
    	texttext.setText(user.getText());
    	this.add(texttext);
    	
    	
		modify_Button = new JButton("�޸�");
		modify_Button.setBounds(70, 345, 60, 25);
		
		
		//ע��"�޸�"��ť�¼�����
		modify_Button.addActionListener(new ActionListener() {
			
			@Override 
			public void actionPerformed(ActionEvent e) {
				Registed newuser = new Registed();
				String username = usernametext.getText().trim();
				String name = nametext.getText().trim();
				String sex = sexbox.getSelectedItem().toString();
				String contact = contacttext.getText().trim();
				String address = addresstext.getText().trim();
				String birthday = birthdaytext.getText().trim();
				String text = texttext.getText().trim();
				//����У�鲿��
				
				if(name.equals("")){
					JOptionPane.showMessageDialog(jd, "��������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}
					
				newuser.setUser_Name(username);
				newuser.setName(name);
				newuser.setSex(sex);
				newuser.setContact(contact);
				newuser.setAddress(address);
				newuser.setBirthday(birthday);
				newuser.setText(text);
				
				if(helper.updateUser(newuser)){
					JOptionPane.showMessageDialog(jd, "�޸ĳɹ���");
					jd.dispose();	//�رյ�ǰ����
					return ;
				}else{
					JOptionPane.showMessageDialog(jd, "�޸�ʧ�ܣ�", "", JOptionPane.WARNING_MESSAGE);
					jd.dispose();	//�رյ�ǰ����
					return ;
				}
			}
			
		});
		this.add(modify_Button);
		
		cancel_Button = new JButton("ȡ��");
		cancel_Button.setBounds(230, 330, 60, 25);
		//ע��"ȡ��"��ť�¼�����
		cancel_Button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jd.dispose();
				
			}
		});
		this.add(cancel_Button);
			
		WindowUtil.setFrameCenter(this);
		this.setResizable(false);
		this.setVisible(true);
	}
}
	
	
	
	
	
		



