package frame;

import model.SPModel;
import util.CreateSql;
import util.WindowUtil;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import dao.ManageHelper;


//��������ѯ����
public class ConditionsSPQueryFrame extends JDialog{
    private JLabel name;    //"�̼���"��ǩ��
    private JLabel spname;	//"��Ʒ��"��ǩ��
    private JLabel classes;	//"���"��ǩ��l
    private JLabel price;	//"�۸�"��ǩ��
    private JLabel number;	//"������ǩ"��
    private JLabel freshdate;	//"������"��ǩ��
    private JTextField nametext;	
    private JTextField spnametext;	
    private JTextField classestext;	
    private JTextField pricetext;	
    private JTextField numbertext;
    private JTextField freshdatetext;		
    private JButton conditions_button;	//��������ѯ��ť 
    private ManageHelper helper;
    private JDialog jd;	//��ǰ����
    /**
	 * 
	 * @param owner ���ĸ�����
	 * @param title ������
	 * @param modal ָ����ģʽ���ڣ����з�ģʽ����
	 */
    public ConditionsSPQueryFrame(JDialog owner, String title, boolean modal,JTable jt){
    	super(owner, title, modal);
    	this.jd = this;
    	this.setLayout(null);
    	
    	name = new JLabel("�̼�:");
    	name.setBounds(29, 19, 30, 20);
    	this.add(name);
    	nametext = new JTextField();
    	nametext.setBounds(65, 19, 100, 20);
    	this.add(nametext);
    	
    	
    	spname = new JLabel("��Ʒ��:");
    	spname.setBounds(200, 19, 30, 20);
    	this.add(spname);
    	spnametext = new JTextField();
    	spnametext.setBounds(240, 19, 100, 20);
    	this.add(spnametext);
    	
    	classes = new JLabel("���:");
    	classes.setBounds(29, 50, 30, 20);
    	this.add(classes);
    	classestext = new JTextField();
    	classestext.setBounds(65, 50, 100, 20);
    	this.add(classestext);
    	
    	price = new JLabel("�۸�:");
    	price.setBounds(200, 50, 30, 20);
    	this.add(price);
    	pricetext = new JTextField();
    	pricetext.setBounds(240, 50, 100, 20);
    	this.add(pricetext);
    	
    	number = new JLabel("����:");
    	number.setBounds(29, 83, 30, 20);
    	this.add(number);
    	numbertext = new JTextField();
    	numbertext.setBounds(65, 83, 100, 20);
    	this.add(numbertext);
    	
    	freshdate = new JLabel("������:");
    	freshdate.setBounds(200, 83, 30, 20);
    	this.add(freshdate);
    	freshdatetext = new JTextField();
    	freshdatetext.setBounds(240, 83, 100, 20);
    	this.add(freshdatetext);
    	
    	
    	
    	conditions_button = new JButton("��������ѯ");
    	conditions_button.setBounds(230, 130, 100, 30);
    	//ע��"��������ѯ"��ť�¼�����
    	conditions_button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String name = nametext.getText().trim();
				String spname = spnametext.getText().trim();
				String classes = classestext.getText().trim();
				String price = pricetext.getText().trim();
				String number = numbertext.getText().trim();
				String freshdate = freshdatetext.getText().trim();
				if(name.equals("")&&spname.equals("")&&classes.equals("")&&price.equals("")&&number.equals("")&&freshdate.equals("")){
					JOptionPane.showMessageDialog(jd, "��������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}else{
					String sql = CreateSql.getSPConditions_Sql(name,spname,classes,price,number,freshdate);
					SPModel sm = new SPModel(sql,jd);
					jt.setModel(sm);
					jd.dispose();
				}
				
			}
		});
    	this.add(conditions_button);
    	
    	
    	this.setSize(411, 222);
    	this.setResizable(false);
    	WindowUtil.setFrameCenter(this);
    	this.setVisible(true);
    }
}
