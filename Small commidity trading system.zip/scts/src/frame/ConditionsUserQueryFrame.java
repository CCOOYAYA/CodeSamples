package frame;

import model.UserModel;
import util.CreateSql;
import util.WindowUtil;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import dao.ManageHelper;


//��������ѯ����
public class ConditionsUserQueryFrame extends JDialog{
    private JLabel username;    //"�û���"��ǩ��
    private JLabel name;	//"����"��ǩ��
    private JLabel sex;	//"�Ա�"��ǩ��l
    private JLabel contact;	//"��ϵ��ʽ"��ǩ��
    private JLabel address;	//"��ַ��ǩ"��
    private JLabel birthday;	//"����"��ǩ��
    private JLabel text;	//"��ע"��ǩ��
    private JTextField usernametext;	
    private JTextField nametext;	
    private JTextField sextext;	
    private JTextField contacttext;	
    private JTextField addresstext;
    private JTextField birthdaytext;	
    private JTextField texttext;	
    private JButton conditions_button;	//��������ѯ��ť 
    private ManageHelper helper;
    private JDialog jd;	//��ǰ����
    /**
	 * 
	 * @param owner ���ĸ�����
	 * @param title ������
	 * @param modal ָ����ģʽ���ڣ����з�ģʽ����
	 */
    public ConditionsUserQueryFrame(JDialog owner, String title, boolean modal,JTable jt){
    	super(owner, title, modal);
    	this.jd = this;
    	this.setLayout(null);
    	
    	username = new JLabel("�û���:");
    	username.setBounds(29, 19, 30, 20);
    	this.add(username);
    	usernametext = new JTextField();
    	usernametext.setBounds(65, 19, 100, 20);
    	this.add(usernametext);
    	
    	
    	name = new JLabel("����:");
    	name.setBounds(200, 19, 30, 20);
    	this.add(name);
    	nametext = new JTextField();
    	nametext.setBounds(240, 19, 100, 20);
    	this.add(nametext);
    	
    	sex = new JLabel("�Ա�:");
    	sex.setBounds(29, 50, 30, 20);
    	this.add(sex);
    	sextext = new JTextField();
    	sextext.setBounds(65, 50, 100, 20);
    	this.add(sextext);
    	
    	contact = new JLabel("��ϵ��ʽ:");
    	contact.setBounds(200, 50, 30, 20);
    	this.add(contact);
    	contacttext = new JTextField();
    	contacttext.setBounds(240, 50, 100, 20);
    	this.add(contacttext);
    	
    	address = new JLabel("��ַ:");
    	address.setBounds(29, 83, 30, 20);
    	this.add(address);
    	addresstext = new JTextField();
    	addresstext.setBounds(65, 83, 100, 20);
    	this.add(addresstext);
    	
    	birthday = new JLabel("����:");
    	birthday.setBounds(200, 83, 30, 20);
    	this.add(birthday);
    	birthdaytext = new JTextField();
    	birthdaytext.setBounds(240, 83, 100, 20);
    	this.add(birthdaytext);
    	
    	text = new JLabel("��ע:");
    	text.setBounds(29,116, 30, 20);
    	this.add(text);
    	texttext = new JTextField();
    	texttext.setBounds(65, 116, 100, 20);
    	this.add(texttext);
    	
    	conditions_button = new JButton("��������ѯ");
    	conditions_button.setBounds(230, 130, 100, 30);
    	//ע��"��������ѯ"��ť�¼�����
    	conditions_button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String id = usernametext.getText().trim();
				String name = nametext.getText().trim();
				String sex = sextext.getText().trim();
				String grade = contacttext.getText().trim();
				String department = addresstext.getText().trim();
				String major = birthdaytext.getText().trim();
				String classe = texttext.getText().trim();
				if(id.equals("")&&name.equals("")&&sex.equals("")&&grade.equals("")&&department.equals("")&&major.equals("")&&classe.equals("")){
					JOptionPane.showMessageDialog(jd, "��������Ϊ�գ�", "", JOptionPane.WARNING_MESSAGE);
					return ;
				}else{
					String sql = CreateSql.getConditions_Sql(id, name, sex, grade, department, major, classe);
					UserModel sm = new UserModel(sql,jd);
					jt.setModel(sm);
					jd.dispose();
				}
				
			}
		});
    	this.add(conditions_button);
    	
    	
    	this.setSize(411, 222);
    	this.setResizable(false);
    	WindowUtil.setFrameCenter(this);
    	this.setVisible(true);
    }
}
