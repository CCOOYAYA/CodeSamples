package util;
//����sql���Ĺ�����
public class CreateSql {

	//���ݲ�ѯ���ݡ�ѡ���ע����ﷵ���ض���sql���
	public static String getUser_Sql(String str,String option){
		String sql = null;
		if("ȫ��".equals(option)){
			sql = "select * from registed" ;
		}else if("�û���".equals(option)){
			sql = "select * from registed where User_name like '%"+str+"%'";
		}else if("����".equals(option)){
			sql = "select * from registed where Name like '%"+str+"%'";
		}else if("�Ա�".equals(option)){
			sql = "select * from registed where Sex like '%"+str+"%'";
		}else if("��ϵ��ʽ".equals(option)){
			sql = "select * from registed where Contact like '%"+str+"%'";
		}else if("��ַ".equals(option)){
			sql = "select * from registed where Address like '%"+str+"%'";
		}else if("����".equals(option)){
			sql = "select * from registed where Birthday  like '%"+str+"%'";
		}else if("��ע".equals(option)){
			sql = "select * from registed where Text like '%"+str+"%'";
		}
		return sql;
	}
	
	//��������ѯ��sql��䴴��
	public static String getConditions_Sql(String id,String name,String sex,String grade,String department,String major,String classe){
		StringBuilder sql = new StringBuilder("select * from registed where 1=1");
		if(!id.equals("")){
			sql.append(" and User_name like '%" + id + "%'  ");
		}
		if(!name.equals("")){
			sql.append(" and Name like '%" + name + "%'  ");
		}
		if(!sex.equals("")){
			sql.append(" and Sex like '%" + sex + "%'  ");
		}
		if(!grade.equals("")){
			sql.append(" and Contact like '%" + grade + "%'  ");
		}
		if(!department.equals("")){
			sql.append(" and Address like '%" + department + "%'  ");
		}
		if(!major.equals("")){
			sql.append(" and Birthday like '%" + major + "%'  ");
		}
		if(!classe.equals("")){
			sql.append(" and Text like '%" + classe + "%'  ");
		}
		
		return sql.toString();
	}
	
	
	
		public static String getSP_Sql(String str,String option){
			String sql = null;
			if("ȫ��".equals(option)){
				sql = "select * from spb" ;
			}else if("�̼�".equals(option)){
				sql = "select * from spb where Name like '%"+str+"%'";
			}else if("����".equals(option)){
				sql = "select * from spb where SPName like '%"+str+"%'";
			}else if("���".equals(option)){
				sql = "select * from spb where Classes like '%"+str+"%'";
			}else if("�۸�".equals(option)){
				sql = "select * from spb where Price like '%"+str+"%'";
			}else if("����".equals(option)){
				sql = "select * from spb where Number like '%"+str+"%'";
			}else if("������".equals(option)){
				sql = "select * from spb where FreshDate  like '%"+str+"%'";
			}
			return sql;
		}
	
	
		
		//��������ѯ��sql��䴴��
		public static String getSPConditions_Sql(String name,String spname,String classes,String price,String number,String freshdate){
			StringBuilder sql = new StringBuilder("select * from spb where 1=1");
			if(!name.equals("")){
				sql.append(" and Name like '%" + name + "%'  ");
			}
			if(!spname.equals("")){
				sql.append(" and SPName like '%" + name + "%'  ");
			}
			if(!classes.equals("")){
				sql.append(" and Classes like '%" + classes + "%'  ");
			}
			if(!price.equals("")){
				sql.append(" and Price like '%" + price + "%'  ");
			}
			if(!number.equals("")){
				sql.append(" and Number like '%" + number + "%'  ");
			}
			if(!freshdate.equals("")){
				sql.append(" and FreshDate like '%" + freshdate + "%'  ");
			}
			
			
			return sql.toString();
		}
		
		public static String getSJ_Sql(String str,String option){
			String sql = null;
			if("ȫ��".equals(option)){
				sql = "select * from registed where identity = 1" ;
			}else if("�̼�".equals(option)){
				sql = "select * from registed where Name like '%"+str+"%'";
			}else if("��ϵ��ʽ".equals(option)){
				sql = "select * from registed where Contact like '%"+str+"%'";
			}else if("��ַ".equals(option)){
				sql = "select * from registed where Address like '%"+str+"%'";
			}else if("��ע".equals(option)){
				sql = "select * from registed where Text like '%"+str+"%'";
			}
			return sql;
		}
		
		
		
		
}	
		
	/*	public static String getSJ_Sql(String str,String option){
			String sql = null;
			if("ȫ��".equals(option)){
				sql = "select Name,Contact,Address,Text from registed" ;
			}
			}else if("�̼���".equals(option)){
				sql = "select Name,Contact,Address,Text from registed where Name like '%"+str+"%'";
			}else if("��ϵ��ʽ".equals(option)){
				sql = "select Name,Contact,Address,Text from registed where Contact like '%"+str+"%'";
			}else if("��ַ".equals(option)){
				sql = "select Name,Contact,Address,Text from registed where Address like '%"+str+"%'";
			}else if("��ע".equals(option)){
				sql = "select Name,Contact,Address,Text from registed where Text like '%"+str+"%'";
			}
			return sql;
		}
		
		//��������ѯ��sql��䴴��
		public static String getSJConditions_Sql(String id,String name,String sex,String grade,String department,String major,String classe){
			StringBuilder sql = new StringBuilder("select Name,Contact,Address,Text from registed where 1=1");
			if(!name.equals("")){
				sql.append(" and Name like '%" + name + "%'  ");
			}
			if(!grade.equals("")){
				sql.append(" and Contact like '%" + grade + "%'  ");
			}
			if(!department.equals("")){
				sql.append(" and Address like '%" + department + "%'  ");
			}
			if(!classe.equals("")){
				sql.append(" and Text like '%" + classe + "%'  ");
			}
			return sql.toString();
		}
		
		
}
}
*/