package bean;


public class Registed {
	private String User_Name;	//�û��˺�
	private String Password; //�û�����
	private int Identity; //�û�����
	private String Name;	//�û�����
	private String Sex;	//�û��Ա�
	private String Contact;	//�û���ϵ��ʽ
	private String Address;	//�û���ַ
	private String Birthday;	//�û�����
	private String Text;  //�û���ע
   
	public String getUser_Name() {
    	return User_Name;
    }
    public void setUser_Name(String User_Name) {
    	this.User_Name = User_Name;
    }
	
    public String getPassword() {
    	return Password;
    }
    public void setPassword(String Password) {
    	this.Password = Password;
    }
    
    public int getIdentity() {
    	return Identity;
    }
    public void setIdentity(int Identity) {
    	this.Identity = Identity;
    }
   
    

    public String getName() {
    	return Name;
    }
    public void setName(String Name) {
    	this.Name = Name;
    }
    
    public String getSex() {
    	return Sex;
    }
    public void setSex(String Sex) {
    	this.Sex = Sex;
    }
    
    public String getContact() {
    	return Contact;
    }
    public void setContact(String Contact) {
    	this.Contact = Contact;
    }
    
    public String getAddress() {
    	return Address;
    }
    public void setAddress(String Address) {
    	this.Address = Address;
    }
    
    public String getBirthday() {
    	return Birthday;
    }
    public void setBirthday(String Birthday) {
    	this.Birthday = Birthday;
    }
     
    public String getText() {
    	return Text;
    }
    public void setText(String Text) {
    	this.Text = Text;
    }
	
	
	
}
