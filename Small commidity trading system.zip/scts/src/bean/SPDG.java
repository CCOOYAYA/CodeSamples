package bean;

public class SPDG {
	private String User_Name;   //�û���
	private String Name;    //�û�����
	private String SPName;     //��Ʒ����
	private String Number;         //��������
	private String OrderDate;     //��������
	private String Text;   //��ע
	
	public String getUser_Name() {
		return User_Name;
	}
	public void setUser_Name(String User_Name) {
		this.User_Name = User_Name;
	}
	
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	
	public String getSPName() {
		return SPName;
	}	
	public void setSPName(String SPName) {
		this.SPName = SPName;
	}
	
	public String getNumber() {
		return Number;
	}
	public void setNumber(String Number) {
		this.Number = Number;
	}
	
	public String getOrderDate() {
		return OrderDate;
	}
	public void setOrderDate(String OrderDate) {
		this.OrderDate = OrderDate;
	}
	
	public String getText() {
		return Text;
	}
	public void setText(String Text) {
		this.Text = Text;
	}

}
