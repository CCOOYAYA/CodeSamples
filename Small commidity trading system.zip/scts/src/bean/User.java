package bean;

public class User {
	private String username;	//�û���
	private String password;	//����
	private String name;	//�û�����
	private int isLogin = 0;	//�û��Ƿ��½
	private int identity;       //�û�����
	private String Sex;	//�û��Ա�
	private String Contact;	//�û���ϵ��ʽ
	private String Address;	//�û���ַ
	private String Birthday;	//�û�����
	private String Text;  //�û���ע
	
	public String getname() {
    	return name;
    }
    public void setname(String name) {
    	this.name = name;
    }
	public int getidentity() {
		return identity;
	}
	public void setidentity (int identity) {
		this.identity = identity;
	}
	public int getIsLogin() { 
		return isLogin;
	}
	public void setIsLogin(int isLogin) {
		this.isLogin = isLogin;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	 public String getSex() {
	    	return Sex;
	    }
	    public void setSex(String Sex) {
	    	this.Sex = Sex;
	    }
	    
	    public String getContact() {
	    	return Contact;
	    }
	    public void setContact(String Contact) {
	    	this.Contact = Contact;
	    }
	    
	    public String getAddress() {
	    	return Address;
	    }
	    public void setAddress(String Address) {
	    	this.Address = Address;
	    }
	    
	    public String getBirthday() {
	    	return Birthday;
	    }
	    public void setBirthday(String Birthday) {
	    	this.Birthday = Birthday;
	    }
	     
	    public String getText() {
	    	return Text;
	    }
	    public void setText(String Text) {
	    	this.Text = Text;
	    }
}
