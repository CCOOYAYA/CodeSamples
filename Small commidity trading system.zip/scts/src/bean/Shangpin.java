package bean;


public class Shangpin {
	private String Name;   //�̼�����
	private String SPName;   //��Ʒ����
	private String Classes;   //��Ʒ����
	private String Price;    //��Ʒ�۸�
	private String Number;    //��Ʒ����
	private String FreshDate;    //��Ʒ������
 	
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	
	public String getSPName() {
		return SPName;
	}
	public void setSPName(String SPName) {
		this.SPName = SPName;
	}
	
	public String getClasses() {
		return Classes;
	}
	public void setClasses(String Classes) {
		this.Classes = Classes;
	}
	
	public String getPrice() {
		return Price;
	}
	public void setPrice(String Price) {
		this.Price = Price;
	}
	
	public String getNumber() {
		return Number;
	}
	public void setNumber(String Number) {
		this.Number = Number;
	}
	
	public String getFreshDate() {
		return FreshDate;
	}
	public void setFreshDate(String FreshDate) {
		this.FreshDate = FreshDate;
	}
}
	
	

