package run;

import frame.LoginFrame;

public class GO {
	public static void main(String[] args) {
		LoginFrame frame = new LoginFrame();
	}
}
 