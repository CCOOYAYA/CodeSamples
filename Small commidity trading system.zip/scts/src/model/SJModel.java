package model;

import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import bean.Registed;
import dao.ManageHelper;

public class SJModel extends AbstractTableModel {
	private ManageHelper helper;
	private Vector<Registed> users;
	private  Vector<String> columnNames = null;	//����
	private Vector<Vector<String>> rowData = null;	//������
	
		
	 public SJModel(String sql,JDialog jd) {
		helper = new ManageHelper();
		users = helper.getUser(sql);
		
		columnNames = new Vector<String>();
		rowData = new Vector<Vector<String>>();
		columnNames.add("�̼���");
		columnNames.add("��ϵ��ʽ");
		columnNames.add("��ַ");
		columnNames.add("��ע");
		for(Registed user : users){
			Vector<String> hang = new Vector<String>();
			hang.add(user.getName());
			hang.add(user.getContact());
			hang.add(user.getAddress());
			hang.add(user.getText());
			rowData.add(hang);
		}
		if(getRowCount()!=0){
			JOptionPane.showMessageDialog(jd, "һ����"+getRowCount()+"����¼��");
			return ;
		}else{
			JOptionPane.showMessageDialog(jd, "û���κμ�¼��");
			return ;
		}
	}
	
	//�õ����ж�����
			@Override
			public int getRowCount() {
				// TODO Auto-generated method stub
				return this.rowData.size();
			}
			//�õ����ж�����
			@Override
			public int getColumnCount() {
				// TODO Auto-generated method stub
				return this.columnNames.size();
			}
			//�õ�ĳ��ĳ�е�����
			@Override
			public Object getValueAt(int rowIndex, int columnIndex) {
				// TODO Auto-generated method stub
				return ((Vector)this.rowData.get(rowIndex)).get(columnIndex);
			}
			
			//��д���� getColumnName
			@Override  
			public String getColumnName(int column) {
				// TODO Auto-generated method stub
				return (String)this.columnNames.get(column);
			}

	}
