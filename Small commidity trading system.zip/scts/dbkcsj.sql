/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : localhost:3306
 Source Schema         : dbkcsj

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 28/05/2019 19:41:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for registed
-- ----------------------------
DROP TABLE IF EXISTS `registed`;
CREATE TABLE `registed`  (
  `User_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0',
  `Password_` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `identity` int(1) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `Sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Contact` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `Birthday` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Text` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IsLogin` bit(1) NULL DEFAULT b'0',
  PRIMARY KEY (`Name`, `User_name`) USING BTREE,
  INDEX `registed_1`(`User_name`) USING BTREE,
  INDEX `registed_2`(`Password_`) USING BTREE,
  INDEX `registed_3`(`identity`) USING BTREE,
  INDEX `Name`(`Name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of registed
-- ----------------------------
INSERT INTO `registed` VALUES ('111', '111', 0, 'admin', NULL, '111', '111', NULL, NULL, b'0');
INSERT INTO `registed` VALUES ('222', '222', 1, 'myp', '男', '123456', '1号 ', '2000-01-01', '帅比', b'0');
INSERT INTO `registed` VALUES ('333', '333', 2, 'wyf', '男 ', '654321', '2号', '2000-02-02', '', b'0');

-- ----------------------------
-- Table structure for spb
-- ----------------------------
DROP TABLE IF EXISTS `spb`;
CREATE TABLE `spb`  (
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SPName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Classes` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Price` float(10, 2) NOT NULL,
  `Number` int(100) UNSIGNED ZEROFILL NOT NULL,
  `FreshDate` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`SPName`) USING BTREE,
  INDEX `spb_1`(`Name`) USING BTREE,
  CONSTRAINT `spb_1` FOREIGN KEY (`Name`) REFERENCES `registed` (`Name`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of spb
-- ----------------------------
INSERT INTO `spb` VALUES ('myp', '可乐', '饮料  ', 5.00, 0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010, '2000-01-01');

-- ----------------------------
-- Table structure for spdgb
-- ----------------------------
DROP TABLE IF EXISTS `spdgb`;
CREATE TABLE `spdgb`  (
  `User_name` char(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SPName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Number` int(255) NOT NULL,
  `OrderDate` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `DeliverDate` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  INDEX `spdgb_1`(`User_name`) USING BTREE,
  INDEX `spdgb_2`(`SPName`) USING BTREE,
  INDEX `spdgb_3`(`Name`) USING BTREE,
  CONSTRAINT `spdgb_1` FOREIGN KEY (`User_name`) REFERENCES `registed` (`User_name`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `spdgb_2` FOREIGN KEY (`SPName`) REFERENCES `spb` (`SPName`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `spdgb_3` FOREIGN KEY (`Name`) REFERENCES `registed` (`Name`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of spdgb
-- ----------------------------
INSERT INTO `spdgb` VALUES ('333', 'wyf', '可乐', 5, '2000-01-01 00:00:00', '2000-02-02 00:00:00');

SET FOREIGN_KEY_CHECKS = 1;
